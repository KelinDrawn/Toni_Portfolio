// case study images BEFORE
import MapNavigationBefore from "@/images/blog/swisscharge/MapNavigationOriginal.png";
import ChargingStationBefore from "@/images/blog/swisscharge/ChargingStationOriginal.png";
import StartChargingBefore from "@/images/blog/swisscharge/StartChargingOriginal.png";
import ReceiptsBefore from "@/images/blog/swisscharge/ChargingHistoryOriginal.png";
import FavoritesBefore from "@/images/blog/swisscharge/FavouritesOriginal.png";
import FilterBefore from "@/images/blog/swisscharge/MapFilterOriginal.png";

// case study images AFTER
import MapNavigationAfter from "@/images/blog/swisscharge/MapNavigationRedesign.png";
import ChargingStationAfter from "@/images/blog/swisscharge/ChargingStationRedesign.png";
import StartChargingAfter from "@/images/blog/swisscharge/StartChargingRedesign.png";
import ReceiptsAfter from "@/images/blog/swisscharge/ChargingHistoryRedesign.png";
import FavoritesAfter from "@/images/blog/swisscharge/FavouritesRedesign.png";
import FilterAfter from "@/images/blog/swisscharge/MapFilterRedesign.png";

import AppStoreIcon from "@/images/blog/swisscharge/AppStoreIconOriginal.png";
import AppStoreReview from "@/images/blog/swisscharge/AppStoreReview.png";

export const pageTitle = "Case Study: Swisscharge iOS App";

export const Topics = [
  "Market and User Research",
  "Heuristic Evaluation",
  "User Interface Design",
  "Prototyping",
];

export const comparisons = [
  {
    title: "Overview with available Charging Stations in the area",
    beforeImage: {
      src: MapNavigationBefore,
      alt: "Original map and navigation interface showing cluttered design",
    },
    afterImage: {
      src: MapNavigationAfter,
      alt: "Redesigned map and navigation interface with improved clarity",
    },
    beforeObservations: [
      "Die Icons und ihre Wirkung: Die Hauptnavigation verwendet ausgefüllte Icons für den Aktiv-State. Basierend auf dieser Logik signalisiert das Filter-Icon das ein oder mehrere Filter aktiv sind, was aber nicht der Fall ist.",
      "Die Suchfunktion: Unscharfe Suchanfragen sind nicht möglich, so wird mit dem Suchbegriff «Sursee» nichts gefunden, nur «Sursee, Schweiz» funktioniert. Alternativ muss manuell aus der Liste ausgewählt werden.",
      "Das Hilfe-Menü: Die Rubrik «Hilfe» wird direkt auf der Kartenebene angeboten. Zum Navigieren der Karte werden vermutlich nur wenige Menschen Hilfe benötigen, später ist eine Kontextsensitive Hilfe vermutlich angebrachter.",
      "Das Menü «Scan QR»: Verdient keine eigene Rubrik. Vergleichbare Apps haben diese Aktion direkt auf der Karte als Button platziert",
    ],
    afterObservations: [
      "iOS26 Liquid Glass: Interface richtet sich nach Apples UI guidelines und die ",
      "Die Suchfunktion: Unscharfe Suchanfragen sind nicht möglich, so wird mit dem Suchbegriff «Sursee» nichts gefunden, nur «Sursee, Schweiz» funktioniert. Alternativ muss manuell aus der Liste ausgewählt werden.",
      "Das Hilfe-Menü: Die Rubrik «Hilfe» wird direkt auf der Kartenebene angeboten. Zum Navigieren der Karte werden vermutlich nur wenige Menschen Hilfe benötigen, später ist eine Kontextsensitive Hilfe vermutlich angebrachter.",
      "Das Menü «Scan QR»: Verdient keine eigene Rubrik. Vergleichbare Apps haben diese Aktion direkt auf der Karte als Button platziert",
    ],
  },
  {
    title: "Filtering for a suitable Charging Stations",
    beforeImage: {
      src: FilterBefore,
      alt: "Original favorites management with limited organization options",
    },
    afterImage: {
      src: FilterAfter,
      alt: "Redesigned favorites management with drag-and-drop and categories",
    },
    beforeObservations: [
      "Es ist nicht immer klar was die entsprechenden Filter für Konsequenzen haben. Z.b. Was ist der Unterschied zwischen «Nur offene Stellen anzeigen» und «Nur freie?» ",
      "Vermutlich sind Optionen wie Mindestleistung und AC/DC-Stationen wichtiger als die Stecker und sollten entsprechend zuerst erscheinen",
      "iOS-Sheet ist vermutlich besser geignet als ein Drawer von rechts",
    ],
    afterObservations: ["–", "–", "–"],
  },
  {
    title: "The details of the selected Charging Location",
    beforeImage: {
      src: ChargingStationBefore,
      alt: "Original charging station detail view with inconsistent design",
    },
    afterImage: {
      src: ChargingStationAfter,
      alt: "Redesigned charging station detail view with improved information hierarchy",
    },
    beforeObservations: [
      "Es befinden sich englische Texte in der deutschen Oberfläche, welche nicht nur sehr klein, sondern zudem vermutlich nicht oder noch nicht relevant. So sehe ich keinen Preis aber dafür den Vertrag mit welchem meine Ladung abgerechnet wird.",
      "Das Icon bzw. dessen Container nimmt enorm viel Platz ein. In der Schweiz sind Typ 2 und CSS fast die einzigen relevanten Anschlüsse um das Elektroauto zu laden, demzufolge muss dem Icon hier nicht eine solche prominenz zugestanden werden.",
      "«Navigation starten» und «Anzeigen» sind beides Links, kommen visuell jedoch verschieden daher.",
      "Das Label des Links «Anzeigen» ist sehr oberflächlich. Was soll hier angezeigt werden? Idealerweise kommuniziert der Link hier klar wo er hinführt, wie z.B. «Details Ladepunkt» oder «Weiter zur Ladung»",
      "Das Navigations-Icon ist Grün, jedoch im Gegensatz zur Verfügbarkeitsanzeige nicht annähernd gleich wichtig, konkurriert aber so diese visuell.",
      "Die Stations-ID ist enorm klein, diese kann oft nützlich sein um sich zu vergewissern vor der korrekten Ladestation zu stehen.",
      "Die «Besetzt»-Farbe ähnelt dem Orange, sollte sich aber visuell klar davon abgrenzen da diese eine Warnung symbolisiert.",
      "«QR-Code scannen» ist bereits eine in der Hauptnavigation aufzufinden, zudem wenn ich bereits auf dieser Detailansicht bin habe ich die korrekte Station ja schon gefunden und brauche keinen Code mehr zu scannen.",
    ],
    afterObservations: [
      "Als User darf muss ich davon ausgehen können das eine Station grundsätzlich verfügbar ist. Dies bedeutet das mein Design grundsätzlich nur die Ausnahme mit einer roten Schrift kennzeichnet, dies hilft auch das Interface etwas zu beruhigen und die Anzahl der Farben im Interface gering zu halten.",
      "–",
      "–",
      "–",
      "–.",
      "–",
      "–",
      "–",
    ],
  },
  {
    subtitle: "Charging an electric car",
    title: "Reviewing selected charging spot and starting the charging session",
    beforeImage: {
      src: StartChargingBefore,
      alt: "Original charging session start interface with unclear process",
    },
    afterImage: {
      src: StartChargingAfter,
      alt: "Redesigned charging session start interface with streamlined flow",
    },
    beforeObservations: [
      "Die Telefonnummer kann nicht direkt angerufen werden, der Nutzer muss sich also die Nummer merken und manuell auf dem Handy eingeben!",
      "Der Preis erscheint visuell fast gleich gross wie die Stations-ID. Kurz bevor man einen Ladevorgang startet, so behaupte ich, ist diese Information enorm wichtig und verdient entsprechend Platz in der Hierarchie.",
      "«Ändern» konkurriert als Link den Haupt-Call-to-Action und sollte visuell weniger auffallen.",
      "«Dauer der gebührenfreien Zeit» ist in Minuten angegeben. Für uns Menschen sind aber Stunden einfacher zu verstehen.",
      "Es ist nicht unmissverständlich klar, das  «Preis pro 1 min» erst nach der gebührenfreien Zeit startet. Es könnte sich um eine andere Gebühr handeln, so sind in der Elektromobilität Blockiergbühren oder Überlastungsgebühren bereits Realität.",
    ],
    afterObservations: ["–", "–", "–"],
  },
  {
    title: "Receipts of past charging sessions",
    beforeImage: {
      src: ReceiptsBefore,
      alt: "Original receipts overview with poor organization",
    },
    afterImage: {
      src: ReceiptsAfter,
      alt: "Redesigned receipts overview with improved filtering and clarity",
    },
    beforeObservations: [
      "Wenn keine Ergebnisse für den aktuellen Zeitraum verfügbar sind kann durch einen automatischen Wechsel zu «Dauer: Alle» verhindert werden das der Screen leer bleibt. Ausser natürlich es wurde noch nie geladen.",
      "Haupttitel wird zweimal wiederholt.",
      "Datum und Uhrzeit vermutlich 1:1 aus der Datenbank, Menschen bevorzugen z.B. 16. Januar 2026, 17.15 Uhr",
      "Verschiedene Pfeile in Verwendung, normaler Pfeil sowie Winkel (Chevron)",
    ],
    afterObservations: [
      "Switch einfacher zu bedienen und alle Optionen sichtbar",
      "Kommastelle weg, und icon oben = mehr platz",
      "besser lesbares Datum",
    ],
  },
  {
    title: "View  Favorites of Charging stations",
    beforeImage: {
      src: FavoritesBefore,
      alt: "Original favorites management with limited organization options",
    },
    afterImage: {
      src: FavoritesAfter,
      alt: "Redesigned favorites management with drag-and-drop and categories",
    },
    beforeObservations: [
      "Visuell ist nicht offensichtlich welche gespeicherten Ladepunkte zueinander gehören.",
      "Wenn ich eine grössere Anzahl von Favoriten speichere muss ich relativ schnell ziemlich viel scrollen da einzelne Ladepunkte viel Platz benötigen.",
      "Um einen Eintrag zu entfernen muss ich zuerst zum entsprechende Ladepunkt auf der Karte navigieren.",
      "Fehlende Preisanzeige. Vermutlich ist es eine bewusste Entscheidung den Preis nicht allzu prominent anzuzeigen. Ich weiss es nicht, ich habe keine Insider-Infos. Als Nutzer möchte ich definitiv diese Information haben.",
      "Aktuell besteht das Problem das bei vielen Favoriten die Liste ziemlich lang werden kann. Wie würde ich dieses Problem lösen? In der Datenbank nach der Durchschnittlichen Anzahl Favoriten suchen und entsprechend eine Lösung finden. Unter anderem ist ein Filter nach Ladeleistung, Entfernung oder Anbieter eine Option",
    ],
    afterObservations: ["–", "–", "–"],
  },
];
